Name:		cod4player

Build:		0.58

Author:		CyboPat

Info:		Utility to play demo files for game "Call of Duty 4: Modern Warfare"
		Click on "keyboard" in main screen to detailed info about key commands.
		
		Tested on Windows XP.

		Windows Vista users: 
		When get this error "Permission denied", run cod4player as Administrator
		(right mouse on cod4player ad select from menu Run as..)

		If You get Error, first check your version on my web and after that, send me info from Error Window to email.

Installation:	Just unzip file "cod4player.exe", but rather don't put it into the COD4 folder.
		Then simply run it.

Web:		http://www.cybopat.net (section Projects)

Email:		cybopat@seznam.cz


Release history:

- 0.58	* added 2 numpad keys for "cheathunters" (g_compassShowEnemies + r_showlightgrid), thanx for inspiration to Rei ceDrix cb team
- 0.57	* better recognising noinstall versions of CoD4 (ask for exe), better support Windows Vista
- 0.56	* fix some bugs + add specify name of mod for "+set fs_game mods\.."
- 0.55	* better control of camera angle (KP_HOME+KP_END) and camera range (KP_MINUS+KP_PLUS)
	* add special key for Quit (KP_SLASH)
- 0.54	* add 2 new keys: camera angle and range
- 0.53	* first release, BIG thanx player "Rellik" to idea "how to.." :)